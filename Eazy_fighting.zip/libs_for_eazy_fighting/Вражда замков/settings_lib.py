lib_name = 'Вражда замков'
enemy_name = 'Вражеский бастион'
zones_id = {1: "ворота", 2: "стену", 3: "восточную башню", 4: "западную башню"}
damage = 100
hp = 1000
vampire = 0
player_turn = True