lib_name = 'Стандартный'
enemy_name = 'Бот'
zones_id = {1: "голову", 2: "тело", 3: "ноги"}
damage = 10
hp = 100
vampire = 0
player_turn = True