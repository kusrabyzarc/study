lib_name = '1hp'
enemy_name = 'Бот'
zones_id = {1: "голову", 2: "тело", 3: "ноги"}
damage = 1
hp = 1
vampire = 0
player_turn = True